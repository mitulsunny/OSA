package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Browser {
	public WebDriver dr;
	@Test
	public void test() {
	System.out.println(System.getProperty("os.name"));
	}
	
@BeforeMethod
public void openB() {
	String os=System.getProperty("os.name");
	if(os.equals("Windows 10")) {
	System.setProperty("webdriver.chrome.driver","src\\main\\resources\\drivers\\chromedriver.exe");
	}else {
	System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver");	
	}
	  dr=new ChromeDriver();
}
@AfterMethod
public void closeB() {
	dr.close();
}
}
