package com.osa.testes;

import org.testng.annotations.Test;

import com.osa.pages.ForumLoginPage;
import com.osa.pages.HomePage;

import Base.Browser;

public class LoginTest extends Browser{
	@Test
	public void loginTest() throws InterruptedException {
		dr.get("https://www.osaconsultingtech.com");
		HomePage homePage=new HomePage(dr);
					Thread.sleep(3000);
		         homePage.clickOnHomeButton();
		         Thread.sleep(3000);
		ForumLoginPage forumLogin=homePage.clickOnForumLogin();
						Thread.sleep(3000);
						forumLogin.enterUsername("mitul.li@yahoo.com");
						Thread.sleep(3000);
						forumLogin.enterPassword("123456789");
						Thread.sleep(3000);
						forumLogin.clickOnLoginButton();
						Thread.sleep(3000);
	}

}
