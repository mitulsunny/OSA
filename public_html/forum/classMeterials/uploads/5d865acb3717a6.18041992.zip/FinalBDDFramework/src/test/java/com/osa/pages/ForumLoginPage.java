package com.osa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.osa.utility.Utility;

public class ForumLoginPage {
	WebDriver dr;
	public ForumLoginPage(WebDriver driver){
		dr=driver;
		PageFactory.initElements(dr,this);
	}
	@FindBy(id="username") 
	WebElement username;
	@FindBy(name="password") 
	WebElement password;
	@FindBy(xpath="//*[@id=\"login_button\"]")
	WebElement loginButton;
	
	public void enterUsername(String user) {
		Utility.type(username, user);
		
	}
	public void enterPassword(String pass) {
		Utility.type(password, pass);
		
	}
	public void clickOnLoginButton() {
		Utility.myClick(loginButton);
	}
	
	
}
