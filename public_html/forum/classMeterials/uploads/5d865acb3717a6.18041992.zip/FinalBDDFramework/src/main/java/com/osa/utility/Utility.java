package com.osa.utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import Base.Browsers;

public class Utility {
/**
 * This method will take path of the porperties fole
 * then it will return properties
 * @param path
 * @return
 */
	public Properties readProperties(String path) {
		Properties pro=null;
		try {
			
		pro=new Properties();
		FileInputStream fis=new FileInputStream(new File(path));
		
		 pro.load(fis);
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return pro;
	}

	public static void type(WebElement element,String value) {
		element.sendKeys(value);
	}
	public static void myClick(WebElement element) {
		element.click();
	}
	public static void verifyTitle(String actual,String expected) {
		Assert.assertEquals(actual, expected);
	}
	
	
	
}
