package com.osa.pages;

import org.openqa.selenium.By;

public class Utility extends Base{
	public void clickOnForumLogin() {
		dr.findElement(By.xpath("/html/body/div[2]/header/div[1]/div/div/div/div/div/div/div/a")).click();
	}
	
	public void sendUserName(String username) {
		dr.findElement(By.id("username")).sendKeys(username);
		
	}
	public void sendPassword(String password) {
		dr.findElement(By.name("password")).sendKeys(password);
	}
	public void clickOnLogin() {
		dr.findElement(By.id("login_button")).click();
	}

}
