package com.osa.test;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SmokeTest extends Browser{
	
	Shared s = new Shared();
	
	@Test
	public void test1() {
		s.gotoURL(dr, "https://osaconsultingtech.com/");
		s.verifyURL(dr, "https://osaconsultingtech.com/");
		
		
	}
	
	@Test
	public void test2() {
		s.gotoURL(dr, "https://osaconsultingtech.com/");
		s.verifyTitle(dr, "OSA Consulting Tech");
		
	}
	
	@Test
	public void test3() {
		s.gotoURL(dr, "https://osaconsultingtech.com/");
		s.click(dr, By.xpath("/html/body/div[2]/header/div[1]/div/div/div/div/div/div/div/a"));
		s.verifyTitle(dr, "Forum Login");
	}
	
	@Test
	public void test4() {
		s.gotoURL(dr, "https://osaconsultingtech.com/");
		s.click(dr, By.xpath("/html/body/div[2]/header/div[1]/div/div/div/div/div/div/div/a"));
		s.sendKeys(dr, By.id("username"), "sdjkfkjdkfjdk");
		s.sendKeys(dr, By.name("password"), "asdjfdkfjik");
		s.click(dr, By.id("login_button"));
		
	}
	
	
	
	

}
