package com.osa.pages;

import org.openqa.selenium.WebDriver;

public class Runner {
	
		
	public static void main(String[] args) throws InterruptedException {
		
		Utility u = new Utility();
		WebDriver dr = u.openBrowser();
		dr.get("https://osaconsultingtech.com/");
		u.clickOnForumLogin();
		u.sendUserName("kdfjdjkfjh");
		u.sendPassword("kdfjkjdkjf");
		u.clickOnLogin();
	
		u.closeBrowser();
		
		
	}
	
	
	
	}
	

