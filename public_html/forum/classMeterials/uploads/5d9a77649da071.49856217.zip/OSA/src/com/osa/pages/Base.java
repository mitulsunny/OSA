package com.osa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Base {
	public WebDriver dr;
	public WebDriver openBrowser() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\md\\Desktop\\OSA0601201901A\\chromedriver.exe");	
	dr=new ChromeDriver();
	return dr;

}
	
	
	public void closeBrowser() throws InterruptedException {
		
		Thread.sleep(4000);
		dr.quit();
	}
}
