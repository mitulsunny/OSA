package com.osa.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browser {
	public WebDriver dr;
	
	@BeforeClass
	public void openB() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\md\\Desktop\\OSA0601201901A\\chromedriver.exe");	
		dr = new ChromeDriver();
		dr.manage().window().maximize();
		
		
	}
	
	
	
	@AfterClass
	public void closeB() throws InterruptedException {
		Thread.sleep(4000);
		dr.quit();
		
	}

}
