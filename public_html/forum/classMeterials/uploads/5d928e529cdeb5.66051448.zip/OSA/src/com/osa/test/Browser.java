package com.osa.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browser {
	public WebDriver dr;
	
	public WebDriver openB() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\md\\Desktop\\OSA0601201901A\\chromedriver.exe");	
		dr = new ChromeDriver();
		dr.manage().window().maximize();
		return dr;
		
	}
	
	
	
	
	public void closeB() throws InterruptedException {
		Thread.sleep(4000);
		dr.quit();
		
	}

}
