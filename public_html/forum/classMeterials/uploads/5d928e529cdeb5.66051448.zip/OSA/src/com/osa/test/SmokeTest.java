package com.osa.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SmokeTest {
	public static void main(String[] args) throws InterruptedException {
		Browser b = new Browser();
		Shared s = new Shared();
		WebDriver dr = b.openB();
		s.gotoURL(dr, "https://osaconsultingtech.com/");
		s.verifyURL(dr, "https://osaconsultingtech.com/");
		s.verifyTitle(dr, "OSA Consulting Tech");
		s.click(dr, By.xpath("/html/body/div[2]/header/div[1]/div/div/div/div/div/div/div/a"));
		s.verifyTitle(dr, "Forum Login");
		s.sendKeys(dr, By.id("username"), "sdjkfkjdkfjdk");
		s.sendKeys(dr, By.name("password"), "asdjfdkfjik");
		s.click(dr, By.id("login_button"));
		
		b.closeB();
		
	}

}
