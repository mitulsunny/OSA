package com.osa.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Shared {
	
	
	public void gotoURL(WebDriver dr, String url) {
		dr.get(url);
	}
	
	public void verifyTitle(WebDriver dr, String expectedTitle) {
		String actualTitle = dr.getTitle();
		if(actualTitle.equals(expectedTitle)) {
			System.out.println("Valid Title");
		}else {
			System.out.println("Invalid Title");
		}
	}
	
	public void verifyURL(WebDriver dr, String expectedURL) {
		String actualURL = dr.getCurrentUrl();
		System.out.println(actualURL);
		if(actualURL.equals(expectedURL)) {
			System.out.println("Valid URL");
		}else {
			System.out.println("Invalid URL");
		}
	}
	
	
	public void click(WebDriver dr, By by ) {
		dr.findElement(by).click();
	}
	
	public void sendKeys(WebDriver dr, By by, String value) {
		dr.findElement(by).sendKeys(value);
	}
	

}
