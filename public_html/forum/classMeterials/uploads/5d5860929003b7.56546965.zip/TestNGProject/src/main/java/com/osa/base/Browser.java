package com.osa.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest; 
import org.testng.annotations.Parameters;

public class Browser {
	public WebDriver dr;
	@BeforeTest
	@Parameters("browser")
	public void openBrowser(String browser) {
		if(browser.equals("chrome")) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\md\\Desktop\\chromedriver.exe");
		 dr=new ChromeDriver();
		}else if (browser.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\md\\Desktop\\geckodriver.exe");
			dr=new FirefoxDriver();
		}
	}
	@AfterTest
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(3000);
		dr.close();
	
	}
	
//	@BeforeTest
//	public void beforeTest() {
//		System.out.println("Before Test");
//	}
//	@AfterTest
//	public void afterTest() {
//		System.out.println("After Test");
//	}
	

}
