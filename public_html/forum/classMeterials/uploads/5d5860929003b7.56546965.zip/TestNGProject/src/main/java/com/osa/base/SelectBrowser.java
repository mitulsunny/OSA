package com.osa.base;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SelectBrowser {
	@Test
	public ChromeDriver myBrowser() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\md\\Desktop\\chromedriver.exe");
	ChromeDriver dr=new ChromeDriver();
		return dr; 
	}

}
