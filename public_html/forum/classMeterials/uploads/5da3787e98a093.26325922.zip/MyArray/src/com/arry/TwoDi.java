package com.arry;

public class TwoDi {

	public static void main(String[] args) {
		//in info[][], first [] is for row and second [] is for column number. 
		String info[][]= {
						  {"OSA","456565656","osa@somfdh.com"},
				          {"Rifat","640954390","rifat@hasldf.com"},
				          {"shah","7575656"},
				          {"Sayeedin","64536345","sayeedin@shfosdf.com"}
				          };
		for(int i=0; i<info.length;i++) {
			for(int j=0;j<info[i].length;j++) {
			System.out.print(info[i][j]+"   ");
			}
			System.out.println();
		///create a method that will return a two dimensional array with the value of 
			/*
			   your four family members firstName, lastName, Gender, and age
			 */
			//Then call the method and print all the value for the array in a different class 
		}
	}
}