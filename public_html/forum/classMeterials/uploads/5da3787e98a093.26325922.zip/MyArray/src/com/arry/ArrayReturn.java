package com.arry;

public class ArrayReturn {
	
public int[] getArray(int number) {
	
	int a[]=new int[number];
	for(int i=0; i<number; i++) {
		a[i]=number-i;
	}
	return a;
}
}
