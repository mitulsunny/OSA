package com.osa.inter;

public interface Toyota {
	public void wheel();


}
