package com.osa.inter;

public class Camry implements Toyota{

	@Override
	public void wheel() {
		System.out.println("Camry wheel");
		
	}




}
