package com.osa.inter;

public class Runn {
public static void main(String[] args) {
	Camry tt=new Camry();
	Toyota t=new Camry();
	Toyota t1=new Corola();
	t.wheel();
	t1.wheel();
}
}
