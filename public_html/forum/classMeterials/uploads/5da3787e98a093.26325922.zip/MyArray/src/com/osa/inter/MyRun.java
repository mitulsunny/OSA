package com.osa.inter;

public class MyRun extends My{
	public static void main(String[] args) {
		MyRun my=new MyRun();
		my.m1();
		my.b();
	}

	@Override
	public void b() {
	System.out.println("Hello");
		
	}

	@Override
	public void a() {
		// TODO Auto-generated method stub
		
	}

}
