package com.osa.inter;

public class Corola implements Toyota{

	@Override
	public void wheel() {
	System.out.println("Corola Wheel");
		
	}

	

}
