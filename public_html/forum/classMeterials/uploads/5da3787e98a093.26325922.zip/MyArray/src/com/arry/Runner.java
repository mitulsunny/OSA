package com.arry;

public class Runner {
	public static void main(String[] args) {
		ArrayReturn re=new ArrayReturn();
		int b[]=re.getArray(12);
		for (int i : b) {
			System.out.println(i);
		}

	}

}
