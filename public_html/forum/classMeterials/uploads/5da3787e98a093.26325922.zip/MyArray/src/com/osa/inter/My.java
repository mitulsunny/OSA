package com.osa.inter;

public abstract class My {
	public void m1() {
		System.out.println("Hi");
	}
	public  void b() {
		System.out.println("Parent Hi");
	}
	public abstract void a();

}
