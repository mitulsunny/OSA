package com.osa.inter;

public class Over {
	public void m1() {
		System.out.println("M1");
	}
	public void m1(int a) {
		System.out.println("M1 a");
	}
	public void m1(double a) {
		System.out.println("M1 double a");
	}
	public void m1(double a, int b) {
		System.out.println(" this is double a and int b");
	}
	public void m1( int b, double a) {
		System.out.println("This is for int b and dobule a");
	}

}
