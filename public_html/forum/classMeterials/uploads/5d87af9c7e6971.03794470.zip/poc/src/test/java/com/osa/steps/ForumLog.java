package com.osa.steps;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.chrome.ChromeDriver;

import com.osa.pages.ForumLoginPage;
import com.osa.utility.Utility;

import Base.Browsers;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ForumLog {
	Utility util=new Utility();
	private static Logger log=Utility.getLog(ForumLog.class);
	Properties pro;
	ChromeDriver dr;
	@Given("^I am on forum login page$")
	public void i_am_on_forum_login_page() throws Throwable {
		log.info("We are opening browser");
	    dr=Browsers.openB();
	    log.info("Navigating to the forum login page");
	    dr.get("https://osaconsultingtech.com/Forum/logins/forum_login.html");
	}

	@When("^I enter username and password$")
	public void i_enter_username_and_password() throws Throwable {
		ForumLoginPage fl=new ForumLoginPage(dr);
		pro=util.readProperties("src\\test\\resources\\testData\\testdata.properties");
		fl.enterUsername(pro.getProperty("username"));
		fl.enterPassword(pro.getProperty("password"));
		
	}

	@And("^I click on forum login button$")
	public void i_click_on_forum_login_button() throws Throwable {
		ForumLoginPage fl=new ForumLoginPage(dr);
		fl.clickOnLoginButton();
	}

	@Then("^I verify that I am in Home page$")
	public void i_verify_that_I_am_in_Home_page() throws Throwable {
	  Utility.verifyTitle("Forum Login", dr.getTitle());
	}

}
