package Base;

import org.junit.Before;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browsers {
	static ChromeDriver dr;

public static ChromeDriver openB() {
	System.setProperty("webdriver.chrome.driver","src\\main\\resources\\drivers\\chromedriver.exe");
	return dr=new ChromeDriver();
}
}
