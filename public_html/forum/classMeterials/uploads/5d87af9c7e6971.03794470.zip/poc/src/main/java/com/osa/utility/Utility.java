package com.osa.utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.osa.steps.ForumLog;


public class Utility {
	private static Logger log=Utility.getLog(ForumLog.class);
/**
 * This method will take path of the porperties fole
 * then it will return properties
 * @param path
 * @return
 */
	public Properties readProperties(String path) {
		Properties pro=null;
		try {
			
		pro=new Properties();
		log.info("Reading properties file for takeing test data");
		FileInputStream fis=new FileInputStream(new File(path));
		log.info("We are able to successfully read the properties file");
		
		 pro.load(fis);
		
		}catch(Exception e) {
			log.info("File path did not find");
			System.out.println(e.getMessage());
		}
		return pro;
	}

	public static void type(WebElement element,String value) {
		log.info("we are typing value "+ value +" in input box based on elements "+element+" provided");
		element.sendKeys(value);
	}
	public static void myClick(WebElement element) {
		log.info("We are performing click operation based on the element "+element+" provided");
		element.click();
	}
	public static void verifyTitle(String actual,String expected) {
		log.info("We are verifying title where ");
		log.info("Expected value is :"+expected +" and Actual value is "+actual);
		Assert.assertEquals(actual, expected);
		log.info("***********************************");
		log.info("Expected and Actual values matched"); 
		log.info("***********************************");
	}
	/**
	 * This method will take the current class as a parameter
	 * and return log object
	 * @param clazz
	 * @return
	 */
	public static Logger getLog(Class clazz) {
		Logger log=Logger.getLogger(clazz);
		PropertyConfigurator.configure("src/test/resources/log4j.properties");
		return log;
	}
	
	
}
