package com.osa.testdata;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ReadXLFile {
	@Test
 public static String[][] testData(String path,String sheetName) {
		//
		XSSFWorkbook workbook=null;
		XSSFSheet sheet=null;
		try {
	  workbook=new XSSFWorkbook(new FileInputStream(new File(path)));
	  sheet=workbook.getSheet(sheetName);
		}catch(Exception e) {
		     System.out.println(e.getMessage());	
			}
	 int numberOfRow=sheet.getLastRowNum();
	 int numberOfCol=sheet.getRow(1).getLastCellNum();
	  String testData[][]=new String[numberOfRow][numberOfCol];
	 for(int i=0;i<numberOfRow;i++) {
		 for(int j=0; j<2;j++) {
			 testData[i][j]=sheet.getRow(i).getCell(j).toString();
		 }
	 }
	 return testData;
 }
}
