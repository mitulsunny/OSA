package com.osa.base;

import org.testng.annotations.Test;

import com.osa.testdata.ReadXLFile;

public class Browser {
@Test
public void useXL() {
	String data[][]=ReadXLFile.testData("C:\\Users\\md\\Desktop\\TestData.xlsx", "Sheet1");
	String data1[][]=ReadXLFile.testData("C:\\Users\\md\\Desktop\\Test.xlsx", "Sheet1");
	System.out.println(data1[0][0]);
	System.out.println(data1[0][1]);
	System.out.println(data1[1][0]);
	System.out.println(data1[1][1]);
}
}
