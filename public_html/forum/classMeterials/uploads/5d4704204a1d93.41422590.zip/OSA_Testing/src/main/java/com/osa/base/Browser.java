package com.osa.base;

import org.openqa.selenium.chrome.ChromeDriver;

public class Browser {
	public ChromeDriver openBrowser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\md\\Desktop\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		return dr;
	}
}
