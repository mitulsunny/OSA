package com.osa.base;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.chrome.ChromeDriver;

public class Runner {
	ChromeDriver  dr;
	@Before
	public void beforeMethod() {
		Browser br=new Browser();
		dr=br.openBrowser();
		dr.get("https://www.osaconsultingtech.com");
	}
	@After 
	public void after() throws InterruptedException {
		Thread.sleep(3000);
		dr.close();
	}
	@Test
	public void test1() {
		String title =dr.getTitle();
		System.out.println(title);
	}
	@Test 
	public void test2() {
		String url=dr.getCurrentUrl();
		System.out.println(url);
	}
	@Test 
	public void test3() {
		String pageSource=dr.getPageSource();
		System.out.println(pageSource);
	}
	

}
