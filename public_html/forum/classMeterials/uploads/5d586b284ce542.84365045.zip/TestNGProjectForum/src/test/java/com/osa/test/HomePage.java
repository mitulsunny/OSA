package com.osa.test;

import org.openqa.selenium.By;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.osa.base.Browser;
public class HomePage extends Browser{
	
	@Test
	public void verifyTitle() throws InterruptedException {
		Thread.sleep(3000);
		dr.get("https://www.osaconsultingtech.com");
		String title=dr.getTitle();
		System.out.println(title);
		Thread.sleep(3000);
		dr.findElement(By.xpath("/html/body/div[2]/header/div[1]/div/div/div/div/div/div/div/a")).click();

	}
	/*@Test
	public void clickOnForumLogin() {
		dr.findElement(By.xpath("/html/body/div[2]/header/div[1]/div/div/div/div/div/div/div/a")).click();
	}*/

}
