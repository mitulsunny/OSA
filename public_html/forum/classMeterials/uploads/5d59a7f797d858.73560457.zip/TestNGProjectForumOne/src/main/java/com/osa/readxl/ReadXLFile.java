package com.osa.readxl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;


public class ReadXLFile {
	public static void main(String[] args) { 
		try {
		ReadXLFile.getTestData();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void getTestData() throws IOException {
		File file=new File("C:\\Users\\md\\Desktop\\myTestData.xlsx");
		FileInputStream fis=new FileInputStream(file);
		XSSFWorkbook workbook=new XSSFWorkbook(fis);
		XSSFSheet sheet=workbook.getSheet("Test");
		for(int i=1;i<5; i++) {
			for(int j=0; j<2; j++) {
				String value=sheet.getRow(i).getCell(j).getStringCellValue();
				//testData[j][i]=value;
				System.out.print("   "+value);
			}
			System.out.println();
		}
		
		
		workbook.close();
	}

}
