package com.osa.test;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.osa.base.Browser;

public class ForumPage extends Browser{
	
	@Test (priority =3)
	public void loginToForum() {
		dr.findElement(By.name("username")).sendKeys("ekdjkfjfd");
		dr.findElement(By.name("password")).sendKeys("ekdjkfjfd");
		dr.findElement(By.id("login_button")).click();
	}
	
	@Test (priority =4)
	public void verifyTitle() {
		String title = dr.getTitle();
		String expextedTitle ="kdjidfijfi" ;
		if(title.equals(expextedTitle)) {
			
			System.out.println("Valid Tilte");
		}
		
	}
}
