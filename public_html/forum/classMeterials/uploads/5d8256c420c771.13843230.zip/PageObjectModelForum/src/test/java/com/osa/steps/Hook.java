package com.osa.steps;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hook {
	@Before
	public void beforeMethod() {
		System.out.println("Running from At beforem method");
	}
	@After
	public void afterMethod() {
		System.out.println("Running from At after method");
	}
	
	
	@Before("@firstScenario")
	public void beforeMethodForSpecificTage() {
		System.out.println("========================================");
	}
	
	@After("@firstScenario")
	public void afterMethodForSpecificTage() {
		System.out.println("+++++++++++++++++++++++++++++++++++++++++++");
	}

}
