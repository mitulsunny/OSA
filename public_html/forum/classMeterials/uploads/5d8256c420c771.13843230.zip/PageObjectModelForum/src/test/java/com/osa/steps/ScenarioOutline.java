package com.osa.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ScenarioOutline {
	@Given("^I am on osa forum login page$")
	public void i_am_on_osa_forum_login_page() throws Throwable {
	System.out.println("I am on Forum login Page");
	}

	@And("^I enter username \"([^\"]*)\" password \"([^\"]*)\"$")
	public void i_enter_username_password(String username, String password) throws Throwable {
	    System.out.println("my username is :"+username+" And my Password is :"+password);
	}

	@When("^I click on login button$")
	public void i_click_on_login_button() throws Throwable {
	    System.out.println("Clicking on login button");
	}

	@Then("^I should be login in osa forum$")
	public void i_should_be_login_in_osa_forum() throws Throwable {
	  System.out.println("verified that I loggedin");
	}
}
