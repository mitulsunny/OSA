package com.osa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	WebDriver dr;
	public HomePage(WebDriver driver){
		dr=driver;
		PageFactory.initElements(dr,this);
	}
	
	
	@FindBy(xpath="/html/body/div[2]/header/div[2]/div/div/div/div/nav/ul/li[1]/a") 
	WebElement homeButton;
	@FindBy(xpath="/html/body/div[2]/header/div[1]/div/div/div/div/div/div/div/a")
	WebElement forumLoginButton;
	
	
	public void clickOnHomeButton() {
		homeButton.click();
	}
	public ForumLoginPage clickOnForumLogin() {
		forumLoginButton.click();
		return new ForumLoginPage(dr);
	}
	 
	
	

}
