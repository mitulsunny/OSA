package com.osa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ForumLoginPage {
	WebDriver dr;
	public ForumLoginPage(WebDriver driver){
		dr=driver;
		PageFactory.initElements(dr,this);
	}
	@FindBy(id="username") 
	WebElement username;
	@FindBy(name="password") 
	WebElement password;
	@FindBy(xpath="//*[@id=\"login_button\"]")
	WebElement loginButton;
	
	public void enterUsername(String user) {
		username.sendKeys(user);
	}
	public void enterPassword(String pass) {
		password.sendKeys(pass);
	}
	public void clickOnLoginButton() {
		loginButton.click();
	}
	
	
}
