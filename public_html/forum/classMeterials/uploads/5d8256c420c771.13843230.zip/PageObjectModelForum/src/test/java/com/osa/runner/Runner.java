package com.osa.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		 features = {"src/test/java/com/osa/features"}
		 ,glue={"com/osa/steps"},
		tags= {"@regression"},
		 plugin = {"html:target/cucumber-html-report", "json:target/cucumber-json-report.json" }
		 ,dryRun=true,
				 monochrome=true,
				 strict=true
		 )
		
public class Runner {

}
