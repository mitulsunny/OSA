package com.osa.steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ForumLogin {
	
	ChromeDriver dr;
	@Given("^I navigating to osa$")
	public void i_navigating_to_osa() throws Throwable {
		System.out.println("I am running from first Given method");
	
	}

	@When("^I click on Forum login button$")
	public void i_click_on_Forum_login_button() throws Throwable {
		System.out.println("I am coming from Forum Loign button method");

	}

	@Then("^I verify the title of the forum login page$")
	public void i_verify_the_title_of_the_forum_login_page() throws Throwable {
	 System.out.println("I am from last method");
	}
	
}
